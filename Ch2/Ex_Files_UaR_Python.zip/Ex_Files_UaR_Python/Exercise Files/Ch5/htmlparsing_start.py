# 
# Example file for parsing and processing HTML
# (For Python 3.x, be sure to use the ExampleSnippets3.txt file)


def main():
  # instantiate the parser and feed it some HTML
  parser = MyHTMLParser()
    

if __name__ == "__main__":
  main();
  