#
# Example file for working with conditional statements
# (For Python 3.x, be sure to use the ExampleSnippets3.txt file)

def main():
  x, y = 10, 100
  
  
if __name__ == "__main__":
  main()
